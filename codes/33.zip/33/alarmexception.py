from __future__ import print_function


class AlarmException(Exception):
    pass